create view new_view(id, "chatId", "lastId") as
SELECT "Chats2".id,
       "Chats2"."chatId",
       "Chats2"."lastId"
FROM "Chats2";

alter table new_view
    owner to postgres;

